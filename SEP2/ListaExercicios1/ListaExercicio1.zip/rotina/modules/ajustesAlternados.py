# Lucas Xavier de Morais
# 12/04/24 
# Programa para fazer os ajustes alternados

def tensaoNasBarras(sistema: Sistema, alpha: float, barras ):

