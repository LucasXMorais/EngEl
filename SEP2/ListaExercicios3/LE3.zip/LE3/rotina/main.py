# Lucas X. de Morais
# 14/08/24 - Rotina para solução da Liste de exercício 3 de otimização
import q1, q2, q3, q4

def main():
    
    print('Questão 1')

    q1.b()

    q1.c()

    print('Questão 2')

    q2.c()

    print('Questão 3')

    q3.a()

    print('Questão 4')

    q4.semana1()
    
    q4.semana2()

    return


if __name__ == '__main__':
    main()


