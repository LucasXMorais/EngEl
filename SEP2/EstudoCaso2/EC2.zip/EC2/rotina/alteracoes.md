TENTATIVA E ERRO:
Barra 1 mudou Vesp(PU) de 1.02 -> 1.07
Barra 1 mudou PGesp(PU) de 0.95 -> 1.1
Barra 6 mudou Vesp(PU) de 1.01 -> 1.03
Barra 12 mudou PGesp(PU) de 0.35 -> 0.6
Circuito 5 mudou TAP(PU) de 1.0 -> 1.05
Circuito 5 mudou DEF(GRAUS) de 5.0 -> -6.2
Circuito 8 mudou TAP(PU) de 1.15 -> 1.05
Circuito 8 mudou DEF(GRAUS) de 0.0 -> -4.0


AJUSTES ALTERNADOS:
Barra 1 mudou Vesp(PU) de 1.02 -> 1.0773
Barra 1 mudou PGesp(PU) de 0.95 -> 1.1
Barra 3 mudou Vesp(PU) de 1.01 -> 1.0173
Barra 6 mudou Vesp(PU) de 1.01 -> 1.0373
Barra 12 mudou Vesp(PU) de 1.0 -> 1.0201
Barra 12 mudou PGesp(PU) de 0.35 -> 0.6
Circuito 5 mudou TAP(PU) de 1.0 -> 1.01
Circuito 5 mudou DEF(GRAUS) de 5.0 -> -6.2
Circuito 8 mudou TAP(PU) de 1.15 -> 1.023
Circuito 8 mudou DEF(GRAUS) de 0.0 -> -4.0
Circuito 12 mudou TAP(PU) de 1.0 -> 1.0114
